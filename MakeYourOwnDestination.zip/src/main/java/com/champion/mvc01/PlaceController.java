package com.champion.mvc01;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PlaceController {
	@Autowired
	PlaceDAO dao;
	
	@RequestMapping("selectList")
	public void selectList(Model model, PlaceDTO placeDTO) {
		System.out.println(placeDTO);
		List<PlaceDTO> list = dao.selectList(placeDTO);
		System.out.println(list);
		model.addAttribute("list", list);
		}
}
