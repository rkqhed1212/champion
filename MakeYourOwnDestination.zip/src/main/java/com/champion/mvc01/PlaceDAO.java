package com.champion.mvc01;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class PlaceDAO {
	
	@Autowired
	SqlSessionTemplate myBatis;
	
	public List<PlaceDTO> selectList(PlaceDTO placeDTO){
		List<PlaceDTO> list = myBatis.selectList("place.selectList", placeDTO);
		return list;
	}
}

