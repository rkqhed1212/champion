$(function() {
	$("#b1").click(function() {
		alert("회원수정이 되었습니다.")
	});
});