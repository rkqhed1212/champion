package com.champion.mvc01;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class PlaceController {
	@Autowired
	PlaceDAO dao;

	@RequestMapping("selectList")
	public void selectList(Model model, PlaceDTO2 placeDTO) {
		System.out.println(placeDTO);
		List<PlaceDTO2> list = dao.selectList(placeDTO);
		model.addAttribute("list", list);
	}

	@RequestMapping("selectList2")
	public void selectList2(Model model) {
		List<PlaceDTO2> list = dao.selectList2();
		model.addAttribute("list", list);
	}

	@RequestMapping("selectone.do")
	public String selectone(Model model, PlaceDTO2 placeDTO) {
		PlaceDTO2 dto2 = dao.selectone(placeDTO);
		model.addAttribute("dto2", dto2);
		return "selectList2";
	}

	@RequestMapping("course")
	public void category(Model model, PlaceDTO2 placeDTO) {
		System.out.println(placeDTO);
		List<PlaceDTO2> list = dao.course(placeDTO);
		model.addAttribute("list", list);
	}

	@RequestMapping("searchedDetail")
	public void searchedDetail(Model model, PlaceDTO2 placeDTO) throws Exception {
		PlaceDTO2 dto = dao.selectone(placeDTO);
		model.addAttribute("dto", dto);
	}
	
	@ResponseBody
	@RequestMapping("navi")
	public List<PlaceDTO2> navi(PlaceDTO2 dto) throws Exception {
		List<PlaceDTO2> list = dao.selectCategory(dto);
		return list;
	}
	
	
}