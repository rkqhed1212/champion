package com.champion.mvc01;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PlaceDAO {

	@Autowired
	SqlSessionTemplate myBatis;

	public List<PlaceDTO2> selectList(PlaceDTO2 placeDTO) {
		List<PlaceDTO2> list = myBatis.selectList("place.selectList", placeDTO);
		return list;
	}

	public List<PlaceDTO2> selectList2() {
		List<PlaceDTO2> list = myBatis.selectList("place.selectList2");
		return list;
	}

	public PlaceDTO2 selectone(PlaceDTO2 placeDTO) {
		PlaceDTO2 dto2 = myBatis.selectOne("place.selectOne", placeDTO);
		return dto2;
	}

	public List<PlaceDTO2> selectCategory(PlaceDTO2 placeDTO) {
		List<PlaceDTO2> list = myBatis.selectList("place.selectCategory", placeDTO);
		return list;
	}

	public List<PlaceDTO2> course(PlaceDTO2 placeDTO) {
	      List<PlaceDTO2> list = myBatis.selectList("place.course", placeDTO);
	      return list;
	   }
	
}
