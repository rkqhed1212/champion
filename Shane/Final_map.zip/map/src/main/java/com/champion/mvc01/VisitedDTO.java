package com.champion.mvc01;

public class VisitedDTO {
   String mid;
   String pname;
   String images;
   int vid;
   
   public int getVid() {
      return vid;
   }
   public void setVid(int vid) {
      this.vid = vid;
   }
   public String getMid() {
      return mid;
   }
   public void setMid(String mid) {
      this.mid = mid;
   }
   public String getPname() {
      return pname;
   }
   public void setPname(String pname) {
      this.pname = pname;
   }
   public String getImages() {
      return images;
   }
   public void setImages(String images) {
      this.images = images;
   }

   
}