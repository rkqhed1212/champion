package com.mega.myod01;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;


@Controller
public class NoticeController {
	
	@Autowired
	FileUploadService fileUploadService;
	
	@Autowired
	NoticeDAO Ndao;
	
	@Autowired
	CommentDAO Cdao;
	
	@RequestMapping("noticeall")
	public void noticeall(Model model) {
		List<NoticeDTO> Nlist = Ndao.selectAll();
		model.addAttribute("Nlist", Nlist);
	}
	
	@RequestMapping("selectone")
	public void selectone(Model model,NoticeDTO dto) throws Exception {
		NoticeDTO dto2 = Ndao.select(dto);
		model.addAttribute("dto", dto2);
	}
	
	@RequestMapping("Ninsert")
	public String Ninsert(Model model,
					@RequestParam("notice_title") String notice_title,
					@RequestParam("notice_content") String notice_content,
					@RequestParam("pname") String pname,
					@RequestParam("mid") String mid,
					@RequestParam("notice_img") MultipartFile file
					) {
//		이미지 경로 저장
		String notice_img = fileUploadService.restore(file);
		NoticeDTO dto = new NoticeDTO();
		dto.setMid(mid);
		dto.setNotice_content(notice_content);
		dto.setNotice_title(notice_title);
		dto.setPname(pname);
		dto.setNotice_img(notice_img);
		Ndao.insert(dto);
		return "success";
	}
	
	@RequestMapping("Ndelete")
	public void del(NoticeDTO dto) {
		Ndao.delete(dto);
	}
}
